<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="<?php echo uri(1);?>">Főoldal</a>
        <a class="nav-link" href="<?php echo uri(2);?>">Tartalmi oldal</a>
        <a class="nav-link" href="<?php echo uri(3);?>">Űrlap</a>
      </div>
    </div>
  </div>
</nav>